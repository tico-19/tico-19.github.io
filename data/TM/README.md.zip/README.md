Use this directory to upload the Translation Memories.

TMX files were created with the Tikal script of the Okapi Framework
https://okapiframework.org/wiki/index.php/Tikal_-_Conversion_Commands#Convert_to_TMX_Format
